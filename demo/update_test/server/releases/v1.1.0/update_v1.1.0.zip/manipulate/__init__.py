"""
客户端操作模块
模仿 0902_leo_client/manipulate 的结构
"""
